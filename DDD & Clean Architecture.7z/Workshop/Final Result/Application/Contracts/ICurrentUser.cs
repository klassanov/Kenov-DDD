﻿namespace CarRentalSystem.Application.Contracts
{
    public interface ICurrentUser
    {
        string UserId { get; }
    }
}
