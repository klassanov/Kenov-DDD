export interface Search {
    manufacturer: string;
    dealer: string;
    category: number;
    minPricePerDay: number;
    maxPricePerDay: number;
}