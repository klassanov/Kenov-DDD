export interface RegisterModelForm {
    email: string;
    password: string;
    name: string;
    phoneNumber: string;
}