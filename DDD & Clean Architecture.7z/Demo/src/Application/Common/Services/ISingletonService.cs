﻿namespace Blog.Application.Common.Services
{
    public interface ISingletonService
    {
    }
}
